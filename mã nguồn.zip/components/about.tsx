export default function About() {
  return (
    <section id="about" className="py-20 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className="relative h-96">
            <img
              src="/coffee-beans-roasting.png"
              alt="Coffee Beans"
              className="w-full h-full object-cover rounded-2xl shadow-xl"
            />
          </div>

          {/* Content */}
          <div className="space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Về <span className="text-primary">Starbucks</span>
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Từ năm 1971, chúng tôi đã cam kết mang đến những tách cà phê tuyệt vời nhất cho khách hàng trên toàn thế
              giới. Mỗi hạt cà phê được chọn lọc từ những vùng trồng tốt nhất.
            </p>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">🌍</span>
                </div>
                <div>
                  <h3 className="font-bold text-foreground mb-1">Toàn cầu</h3>
                  <p className="text-muted-foreground">Có mặt ở hơn 80 quốc gia trên thế giới</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">♻️</span>
                </div>
                <div>
                  <h3 className="font-bold text-foreground mb-1">Bền vững</h3>
                  <p className="text-muted-foreground">Cam kết với môi trường và cộng đồng</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">⭐</span>
                </div>
                <div>
                  <h3 className="font-bold text-foreground mb-1">Chất lượng</h3>
                  <p className="text-muted-foreground">Chỉ sử dụng những hạt cà phê tốt nhất</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
