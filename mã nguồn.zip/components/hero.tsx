import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-primary/10 to-accent/10 py-20 md:py-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl -z-10"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight">
              Khám phá hương vị <span className="text-primary">cà phê hoàn hảo</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Từ những hạt cà phê được chọn lọc kỹ lưỡng đến những công thức độc quyền, chúng tôi mang đến trải nghiệm
              cà phê tuyệt vời nhất.
            </p>
            <div className="flex gap-4 pt-4">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-base">
                Khám phá ngay
              </Button>
              <Button
                variant="outline"
                className="px-8 py-6 text-base border-primary text-primary hover:bg-primary/5 bg-transparent"
              >
                Tìm hiểu thêm
              </Button>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative h-96 md:h-full">
            <img
              src="/starbucks-coffee-cup-latte-art.jpg"
              alt="Starbucks Coffee"
              className="w-full h-full object-cover rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
