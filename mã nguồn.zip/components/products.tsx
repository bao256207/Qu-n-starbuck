import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const products = [
  {
    id: 1,
    name: "Espresso",
    description: "Cà phê đậm đà, mạnh mẽ",
    price: "45.000đ",
    image: "/espresso-coffee-cup.png",
  },
  {
    id: 2,
    name: "Cappuccino",
    description: "Kết hợp hoàn hảo giữa espresso và sữa",
    price: "55.000đ",
    image: "/cappuccino-latte-art.jpg",
  },
  {
    id: 3,
    name: "Americano",
    description: "Espresso pha với nước nóng",
    price: "50.000đ",
    image: "/americano-coffee.png",
  },
  {
    id: 4,
    name: "Macchiato",
    description: "Espresso với một chút sữa nóng",
    price: "52.000đ",
    image: "/macchiato-coffee.png",
  },
  {
    id: 5,
    name: "Latte",
    description: "Cà phê mềm mại với nhiều sữa",
    price: "58.000đ",
    image: "/latte-coffee-cup.png",
  },
  {
    id: 6,
    name: "Mocha",
    description: "Latte với chocolate ngon lành",
    price: "62.000đ",
    image: "/mocha-chocolate-coffee.jpg",
  },
]

export default function Products() {
  return (
    <section id="products" className="py-20 md:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Thực đơn cà phê của chúng tôi</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Từ những công thức cổ điển đến những sáng tạo hiện đại, tất cả đều được chế biến với tình yêu
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-48 overflow-hidden bg-muted">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-primary">{product.name}</CardTitle>
                <CardDescription>{product.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary">{product.price}</span>
                  <button className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded-lg transition">
                    Thêm vào giỏ
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
