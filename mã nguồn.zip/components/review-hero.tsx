"use client"

import { Star, Search } from "lucide-react"
import { useState } from "react"

export default function ReviewHero() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <section className="bg-gradient-to-br from-primary to-accent py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4 text-balance">
            Khám Phá Các Quán Starbucks Tốt Nhất
          </h1>
          <p className="text-lg text-primary-foreground/90 mb-8 text-balance">
            Đọc đánh giá từ cộng đồng và tìm quán Starbucks yêu thích của bạn
          </p>

          {/* Search Bar */}
          <div className="flex gap-2 max-w-2xl mx-auto">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Tìm kiếm quán Starbucks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>
            <button className="px-6 py-3 bg-accent text-accent-foreground rounded-lg font-semibold hover:opacity-90 transition">
              Tìm
            </button>
          </div>
        </div>

        {/* Stats Preview */}
        <div className="grid grid-cols-3 gap-4 md:gap-8 text-center">
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary-foreground mb-2">4.8</div>
            <div className="flex justify-center gap-1 mb-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-accent text-accent" />
              ))}
            </div>
            <p className="text-sm text-primary-foreground/80">Đánh giá trung bình</p>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary-foreground mb-2">2,450+</div>
            <p className="text-sm text-primary-foreground/80">Đánh giá</p>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary-foreground mb-2">45</div>
            <p className="text-sm text-primary-foreground/80">Quán Starbucks</p>
          </div>
        </div>
      </div>
    </section>
  )
}
