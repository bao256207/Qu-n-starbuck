"use client"

import { Star, MapPin, Clock, Phone } from "lucide-react"

interface Store {
  id: number
  name: string
  location: string
  address: string
  rating: number
  reviewCount: number
  hours: string
  phone: string
  image: string
  reviews: Array<{
    author: string
    rating: number
    text: string
    date: string
  }>
}

const stores: Store[] = [
  {
    id: 1,
    name: "Starbucks Hoan Kiem",
    location: "Hà Nội",
    address: "123 Đường Tràng Tiền, Hoàn Kiếm, Hà Nội",
    rating: 4.9,
    reviewCount: 342,
    hours: "6:00 AM - 10:00 PM",
    phone: "(024) 3825-1234",
    image: "/starbucks-cafe-interior.jpg",
    reviews: [
      {
        author: "Nguyễn Văn A",
        rating: 5,
        text: "Quán rất sạch sẽ, nhân viên thân thiện. Cà phê ngon, giá hợp lý. Sẽ quay lại!",
        date: "2 ngày trước",
      },
      {
        author: "Trần Thị B",
        rating: 5,
        text: "Không gian thoải mái, wifi nhanh. Hoàn hảo để làm việc!",
        date: "1 tuần trước",
      },
    ],
  },
  {
    id: 2,
    name: "Starbucks Trang Tien Plaza",
    location: "Hà Nội",
    address: "191 Trần Hưng Đạo, Hoàn Kiếm, Hà Nội",
    rating: 4.7,
    reviewCount: 289,
    hours: "7:00 AM - 9:00 PM",
    phone: "(024) 3825-5678",
    image: "/starbucks-modern-cafe.jpg",
    reviews: [
      {
        author: "Lê Minh C",
        rating: 4,
        text: "Tốt nhưng hơi đông vào giờ cao điểm. Nhân viên vẫn phục vụ nhanh.",
        date: "3 ngày trước",
      },
      {
        author: "Phạm Hồng D",
        rating: 5,
        text: "Vị trí đẹp, view tuyệt vời. Đáng để ghé!",
        date: "5 ngày trước",
      },
    ],
  },
  {
    id: 3,
    name: "Starbucks Bitexco",
    location: "TP. Hồ Chí Minh",
    address: "2 Hải Triều, Bến Nghé, Quận 1, TP.HCM",
    rating: 4.8,
    reviewCount: 456,
    hours: "6:30 AM - 10:30 PM",
    phone: "(028) 3821-1111",
    image: "/starbucks-city-view.jpg",
    reviews: [
      {
        author: "Võ Thị E",
        rating: 5,
        text: "Tuyệt vời! View Sài Gòn từ quán rất đẹp. Cà phê chất lượng cao.",
        date: "1 ngày trước",
      },
      {
        author: "Đặng Văn F",
        rating: 5,
        text: "Dịch vụ xuất sắc, không gian sang trọng. Giá hơi cao nhưng xứng đáng.",
        date: "4 ngày trước",
      },
    ],
  },
  {
    id: 4,
    name: "Starbucks Landmark 81",
    location: "TP. Hồ Chí Minh",
    address: "Vinhomes Central Park, 720A Điện Biên Phủ, Bình Thạnh, TP.HCM",
    rating: 4.6,
    reviewCount: 378,
    hours: "7:00 AM - 9:00 PM",
    phone: "(028) 3821-2222",
    image: "/starbucks-luxury-cafe.jpg",
    reviews: [
      {
        author: "Hoàng Minh G",
        rating: 4,
        text: "Không gian hiện đại, nhân viên chuyên nghiệp. Hơi đắt một chút.",
        date: "2 tuần trước",
      },
      {
        author: "Bùi Thị H",
        rating: 5,
        text: "Tuyệt vời! Cà phê ngon, không gian đẹp, phục vụ tốt.",
        date: "3 tuần trước",
      },
    ],
  },
  {
    id: 5,
    name: "Starbucks Da Nang Beach",
    location: "Đà Nẵng",
    address: "88 Võ Nguyên Giáp, Mỹ Khê, Ngũ Hành Sơn, Đà Nẵng",
    rating: 4.9,
    reviewCount: 267,
    hours: "6:00 AM - 11:00 PM",
    phone: "(0236) 3821-3333",
    image: "/starbucks-beach-view.jpg",
    reviews: [
      {
        author: "Trương Văn I",
        rating: 5,
        text: "Tuyệt vời! View biển Mỹ Khê tuyệt đẹp. Cà phê ngon, giá hợp lý.",
        date: "1 tuần trước",
      },
      {
        author: "Ngô Thị J",
        rating: 5,
        text: "Nơi lý tưởng để thư giãn. Nhân viên rất thân thiện!",
        date: "2 tuần trước",
      },
    ],
  },
  {
    id: 6,
    name: "Starbucks Hoi An Ancient Town",
    location: "Hội An",
    address: "Số 1 Nguyễn Huệ, Phố Cổ, Hội An, Quảng Nam",
    rating: 4.7,
    reviewCount: 198,
    hours: "7:00 AM - 10:00 PM",
    phone: "(0235) 3821-4444",
    image: "/starbucks-ancient-town.jpg",
    reviews: [
      {
        author: "Phan Văn K",
        rating: 5,
        text: "Tuyệt vời! Kết hợp hiện đại với phố cổ. Cà phê ngon!",
        date: "3 ngày trước",
      },
      {
        author: "Lý Thị L",
        rating: 4,
        text: "Đẹp nhưng hơi đông. Nhân viên vẫn phục vụ tốt.",
        date: "1 tuần trước",
      },
    ],
  },
]

export default function StoreReviews() {
  return (
    <section id="stores" className="py-12 md:py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-12">Đánh Giá Quán Starbucks</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {stores.map((store) => (
            <div
              key={store.id}
              className="bg-card rounded-lg border border-border overflow-hidden hover:shadow-lg transition"
            >
              {/* Store Image */}
              <img src={store.image || "/placeholder.svg"} alt={store.name} className="w-full h-48 object-cover" />

              {/* Store Info */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-xl font-bold text-foreground">{store.name}</h3>
                    <div className="flex items-center gap-2 text-muted-foreground mt-1">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{store.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 justify-end mb-1">
                      <span className="text-lg font-bold text-foreground">{store.rating}</span>
                      <Star className="w-5 h-5 fill-accent text-accent" />
                    </div>
                    <span className="text-xs text-muted-foreground">{store.reviewCount} đánh giá</span>
                  </div>
                </div>

                {/* Store Details */}
                <div className="space-y-2 mb-4 pb-4 border-b border-border">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>{store.hours}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span>{store.phone}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{store.address}</p>
                </div>

                {/* Recent Reviews */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-foreground text-sm">Đánh giá gần đây</h4>
                  {store.reviews.map((review, idx) => (
                    <div key={idx} className="bg-muted/50 rounded p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-sm text-foreground">{review.author}</span>
                        <div className="flex gap-0.5">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${i < review.rating ? "fill-accent text-accent" : "text-muted-foreground"}`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mb-1">{review.date}</p>
                      <p className="text-sm text-foreground">{review.text}</p>
                    </div>
                  ))}
                </div>

                {/* View More Button */}
                <button className="w-full mt-4 py-2 px-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition">
                  Xem tất cả đánh giá
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
