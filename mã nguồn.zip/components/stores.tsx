import { MapPin, Phone, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const stores = [
  {
    id: 1,
    name: "Starbucks Hà Nội - Tây Hồ",
    address: "123 Đường Thanh Niên, Tây Hồ, Hà Nội",
    phone: "(024) 3718 1234",
    hours: "6:00 - 22:00",
  },
  {
    id: 2,
    name: "Starbucks TP.HCM - Quận 1",
    address: "456 Đường Nguyễn Huệ, Quận 1, TP.HCM",
    phone: "(028) 3821 5678",
    hours: "6:00 - 23:00",
  },
  {
    id: 3,
    name: "Starbucks Đà Nẵng",
    address: "789 Đường Bạch Đằng, Hải Châu, Đà Nẵng",
    phone: "(0236) 3822 9999",
    hours: "6:30 - 22:00",
  },
]

export default function Stores() {
  return (
    <section id="stores" className="py-20 md:py-32 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Tìm cửa hàng gần bạn</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Ghé thăm một trong những cửa hàng Starbucks của chúng tôi để thưởng thức cà phê tuyệt vời
          </p>
        </div>

        {/* Stores Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {stores.map((store) => (
            <Card key={store.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-primary text-lg">{store.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-3">
                  <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <p className="text-muted-foreground">{store.address}</p>
                </div>
                <div className="flex gap-3">
                  <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <p className="text-muted-foreground">{store.phone}</p>
                </div>
                <div className="flex gap-3">
                  <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <p className="text-muted-foreground">{store.hours}</p>
                </div>
                <button className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground py-2 rounded-lg transition font-medium">
                  Chỉ đường
                </button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
