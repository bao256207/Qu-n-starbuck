import { Facebook, Instagram, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary-foreground rounded-full flex items-center justify-center">
                <span className="text-primary font-bold">☕</span>
              </div>
              <span className="text-xl font-bold">Starbucks</span>
            </div>
            <p className="text-primary-foreground/80">Khám phá hương vị cà phê hoàn hảo</p>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-bold mb-4">Sản phẩm</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Cà phê
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Trà
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Bánh ngọt
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Đồ uống lạnh
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-bold mb-4">Công ty</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Về chúng tôi
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Tuyển dụng
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Tin tức
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition">
                  Liên hệ
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="font-bold mb-4">Theo dõi chúng tôi</h3>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center hover:bg-primary-foreground/30 transition"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center hover:bg-primary-foreground/30 transition"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary-foreground/20 rounded-lg flex items-center justify-center hover:bg-primary-foreground/30 transition"
              >
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-primary-foreground/20 pt-8 flex flex-col md:flex-row justify-between items-center text-primary-foreground/80 text-sm">
          <p>&copy; 2025 Starbucks. Tất cả quyền được bảo lưu.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary-foreground transition">
              Chính sách bảo mật
            </a>
            <a href="#" className="hover:text-primary-foreground transition">
              Điều khoản sử dụng
            </a>
            <a href="#" className="hover:text-primary-foreground transition">
              Cài đặt cookie
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
