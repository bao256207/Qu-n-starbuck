"use client"

import { Star } from "lucide-react"

export default function ReviewStats() {
  const stats = [
    { stars: 5, count: 1200, percentage: 49 },
    { stars: 4, count: 800, percentage: 33 },
    { stars: 3, count: 300, percentage: 12 },
    { stars: 2, count: 100, percentage: 4 },
    { stars: 1, count: 50, percentage: 2 },
  ]

  return (
    <section className="py-12 md:py-16 bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">Phân Bố Đánh Giá</h2>

        <div className="space-y-4">
          {stats.map((stat) => (
            <div key={stat.stars} className="flex items-center gap-4">
              <div className="flex items-center gap-2 w-24">
                <span className="text-sm font-semibold text-foreground">{stat.stars}</span>
                <Star className="w-4 h-4 fill-accent text-accent" />
              </div>
              <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                <div
                  className="bg-accent h-full rounded-full transition-all"
                  style={{ width: `${stat.percentage}%` }}
                ></div>
              </div>
              <div className="text-right w-20">
                <span className="text-sm font-semibold text-foreground">{stat.count}</span>
                <span className="text-xs text-muted-foreground ml-2">({stat.percentage}%)</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
