"use client"

import { useState } from "react"
import { Menu, X, ShoppingCart, MessageCircle } from "lucide-react"
import Link from "next/link"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">☕</span>
          </div>
          <span className="text-xl font-bold text-primary">Starbucks</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#products" className="text-foreground hover:text-primary transition">
            Sản phẩm
          </a>
          <a href="#about" className="text-foreground hover:text-primary transition">
            Về chúng tôi
          </a>
          <a href="#stores" className="text-foreground hover:text-primary transition">
            Cửa hàng
          </a>
          <a href="#contact" className="text-foreground hover:text-primary transition">
            Liên hệ
          </a>
          <Link href="/chatbot" className="text-foreground hover:text-primary transition flex items-center gap-2">
            <MessageCircle className="w-4 h-4" />
            Trợ Lý Ảo
          </Link>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          <button className="relative p-2 hover:bg-muted rounded-lg transition">
            <ShoppingCart className="w-5 h-5 text-primary" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full"></span>
          </button>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 hover:bg-muted rounded-lg transition">
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden border-t border-border bg-card">
          <div className="px-4 py-4 space-y-3">
            <a href="#products" className="block text-foreground hover:text-primary transition py-2">
              Sản phẩm
            </a>
            <a href="#about" className="block text-foreground hover:text-primary transition py-2">
              Về chúng tôi
            </a>
            <a href="#stores" className="block text-foreground hover:text-primary transition py-2">
              Cửa hàng
            </a>
            <a href="#contact" className="block text-foreground hover:text-primary transition py-2">
              Liên hệ
            </a>
            <Link
              href="/chatbot"
              className="block text-foreground hover:text-primary transition py-2 flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              Trợ Lý Ảo
            </Link>
          </div>
        </div>
      )}
    </header>
  )
}
