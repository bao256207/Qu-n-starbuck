"use client"

export default function ChatbotPage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Trợ Lý Ảo Starbucks</h1>
          <p className="text-lg text-muted-foreground">
            Hãy trò chuyện với trợ lý ảo của chúng tôi để được hỗ trợ về sản phẩm, đặt hàng, và các câu hỏi khác
          </p>
        </div>

        {/* Botpress Chatbot Container */}
        <div className="bg-white rounded-lg shadow-lg p-8 min-h-96">
          <iframe
            src="https://cdn.botpress.cloud/webchat/v3.3/shareable.html?configUrl=https://files.bpcontent.cloud/2025/10/17/03/20251017030737-9F7DN53N.json"
            title="Starbucks Chatbot"
            className="w-full h-96 border-0 rounded-lg"
            allow="microphone; camera"
          />
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-card p-6 rounded-lg text-center">
            <h3 className="text-xl font-semibold text-foreground mb-2">Hỗ Trợ 24/7</h3>
            <p className="text-muted-foreground">Trợ lý ảo luôn sẵn sàng giúp bạn bất kỳ lúc nào</p>
          </div>
          <div className="bg-card p-6 rounded-lg text-center">
            <h3 className="text-xl font-semibold text-foreground mb-2">Trả Lời Nhanh</h3>
            <p className="text-muted-foreground">Nhận câu trả lời tức thì cho các câu hỏi của bạn</p>
          </div>
          <div className="bg-card p-6 rounded-lg text-center">
            <h3 className="text-xl font-semibold text-foreground mb-2">Dễ Sử Dụng</h3>
            <p className="text-muted-foreground">Giao diện đơn giản và thân thiện với người dùng</p>
          </div>
        </div>
      </div>
    </main>
  )
}
