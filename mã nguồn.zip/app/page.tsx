import Header from "@/components/header"
import Hero from "@/components/hero"
import Products from "@/components/products"
import About from "@/components/about"
import Stores from "@/components/stores"
import Contact from "@/components/contact"
import ReviewStats from "@/components/review-stats"
import StoreReviews from "@/components/store-reviews"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Products />
      <ReviewStats />
      <StoreReviews />
      <About />
      <Stores />
      <Contact />
      <Footer />
    </main>
  )
}
